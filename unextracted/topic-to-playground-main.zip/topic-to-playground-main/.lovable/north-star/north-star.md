<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Kids learn what it really takes to keep people alive on Mars.

## Metric

Missions played through to their ending each week
